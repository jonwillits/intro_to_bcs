class Dataset:
    dataset_type = "and"

class App:
    dimensions = (950, 600)

class Network:
    input_size = 2
    output_size = 1
    learning_rate = 0.01
    activation_function = "sigmoid"
    hidden_size_list = ()